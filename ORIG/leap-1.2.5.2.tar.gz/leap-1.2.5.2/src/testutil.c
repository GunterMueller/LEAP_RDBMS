#include "util.h"


void main () {

	char test[180],post[180],p2[180];


	strcpy(test,"(subject,STRING,10)");

	printf("pre: >%s<\n",test);

	cut_to_right_bracket(test,1,FALSE,post);
	printf("post: >%s<\ntest: >%s<\n",post,test);
	cut_to_right_bracket(post,1,FALSE,p2);
	printf("post: >%s<\np2: >%s<\n",post,p2);

}
