/* 
 * Name: vars.h
 * Description: Variable maintenance file
 * Version: vars.h,v 1.200.2.1 1998/10/24 16:34:53 rleyton Exp
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996-1998 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA, England. E-Mail: rleyton@acm.org
 *   http://www.dogbert.demon.co.uk/leap.html
 *
 */

#ifdef HAVE_CONFIG_H
#include "defines.h"
#endif

#ifndef _LEAP_VARIABLES_
#define _LEAP_VARIABLES_

#include "dtypes.h"

extern char *resolve_variable(char *variable);
extern char *set_variable(char *variable, char *value);
extern int init_variables(void);
extern void show_variables(void);
extern int new_variable(char *var_name, char *var_value) ;

#endif
